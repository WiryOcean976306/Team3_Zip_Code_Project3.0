/**
 * @file BlockedSequence.h
 * @author Zach Houck
 * @date 2026-03-26
 * @brief Declares the BlockedSequence container used to manage linked blocks by RBN.
 *
 * The sequence stores blocks in memory and maintains logical ordering through
 * each block's previous and next relative block number (RBN).
 */

#ifndef BLOCKEDSEQUENCE_H
#define BLOCKEDSEQUENCE_H

#include <map>
#include <queue>
#include <string>

#include "Block.h"

using namespace std;

class BlockedSequence
{
    private:
        /** Maps each block's RBN to the corresponding in-memory Block object. */
        map<int, Block> blocks;
        /** RBN of the first block in the logical sequence (0 when empty). */
        int HeadRBN = 0;
        /** RBN of the last block in the logical sequence (0 when empty). */
        int TailRBN = 0;
        /** Next RBN value to assign when a new block is created. */
        int NextRBN = 1;
        /** Queue of RBNs for blocks that have been deleted and are available for reuse. */
        queue<int> availList;
        /** Configured maximum payload bytes per block. */
        int BlockByteMaxSize = 512;
        /** Configured minimum payload bytes per block. */
        int BlockByteMinSize = 256;

    public:
        
        /**
         * @brief Constructs an empty blocked sequence.
         * @param startRBN Initial RBN value to assign to the first created block.
         * @details Initializes head and tail as empty (0) and stores the next
         *          RBN counter used for newly allocated blocks.
         */
        BlockedSequence(int startRBN = 1);

        /**
         * @brief Indicates whether the sequence has any blocks.
         * @return True when no blocks are currently linked; otherwise false.
         */
        bool IsEmpty();

        /**
         * @brief Returns the RBN of the head block.
         * @return Head block RBN, or 0 when the sequence is empty.
         */
        int GetHeadRBN();

        /**
         * @brief Returns the RBN of the tail block.
         * @return Tail block RBN, or 0 when the sequence is empty.
         */
        int GetTailRBN();

        /**
         * @brief Returns the next RBN that will be assigned to a new block.
         * @return Next available RBN value.
         */
        int GetNextRBN();

        /**
         * @brief Returns the number of blocks currently tracked in memory.
         * @return Count of blocks in the internal map.
         */
        int GetCount();

        /**
         * @brief Configures target block capacities for subsequently created blocks.
         * @param blockSize Maximum payload bytes per block.
         * @param minCapacity Minimum block fill ratio in range (0.0, 1.0].
         */
        void SetBlockCapacity(int blockSize, double minCapacity);

        /**
         * @brief Appends one packed record to the logical tail of the sequence.
         * @param recordCsv Length-indicated record payload to append.
         * @return True if the record is inserted into an existing or new block;
         *         otherwise false.
         * @details If the current tail block has space, the record is inserted there.
         *          If not, a new block is created, linked after the tail, and the
         *          record is inserted into the new block.
         */
        bool AppendRecord(const string& recordCsv);

        /**
         * @brief Writes every linked block from head to tail.
         * @return True if all blocks are written successfully; otherwise false.
         * @details Traverses the active chain using each block's next-RBN pointer
         *          and calls Block::WriteBlock on each visited block.
         */
        bool WriteAll();

        /**
         * @brief Reads every linked block from head to tail.
         * @return True if all blocks are read successfully; otherwise false.
         * @details Traverses the active chain using each block's next-RBN pointer
         *          and calls Block::ReadBlock on each visited block.
         */
        bool LoadAllFromHead();

        /**
         * @brief Looks up a block by relative block number.
         * @param rbn RBN key of the block to locate.
         * @return Pointer to the matching block, or nullptr if not found.
         */
        Block* GetBlock(int rbn);


        /**
         * @brief Dumps the logical sequence of records from head to tail as a string.
         * @return A string representation of all records in logical order.
         * @details Traverses the active chain and concatenates the records from each
         *          block into a single string for display or debugging purposes.
         */
        string DumpLogicalOrder();

        /**
         * @brief Dumps active blocks in physical order (ascending RBN map order).
         * @return Formatted dump with list heads, links, and record keys per block.
         */
        string DumpPhysicalBlockOrder();

        /**
         * @brief Dumps active blocks in logical order (following next-RBN chain).
         * @return Formatted dump with list heads, links, and record keys per block.
         */
        string DumpLogicalBlockOrder();

        /**
         * @brief Inserts a record into the appropriate block, handling block splits if needed.
         * @param recordCsv Packed record to insert.
         * @param logOutput Reference to string where split/insert events are logged.
         * @return True if insert succeeds; otherwise false.
         * @details Searches existing blocks for the correct position, or creates a new block.
         *          If a block reaches capacity during insert, it is split and event is logged.
         */
        bool Insert(const string& recordCsv, string& logOutput);

        /**
         * @brief Deletes a record by ZIP key, handling block merges/redistributions if needed.
         * @param zipKey ZIP code to delete.
         * @param logOutput Reference to string where delete/merge/redistribution events are logged.
         * @return True if deletion succeeds; otherwise false.
         * @details Searches blocks for the key, removes it, and handles merge if block becomes underfull.
         */
        bool Delete(const string& zipKey, string& logOutput);

        /**
         * @brief Returns the number of blocks currently in the available list.
         * @return Count of blocks in the available list.
         */
        int GetAvailListSize();
};

#endif